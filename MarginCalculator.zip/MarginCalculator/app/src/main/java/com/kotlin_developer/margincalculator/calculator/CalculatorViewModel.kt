package com.kotlin_developer.margincalculator.calculator

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import timber.log.Timber

class CalculatorViewModel : ViewModel(){
    var operatorEnabled: Boolean = false
    var firstResult : Double = 0.0
    var secondResult= MutableLiveData<Double>()
    var operator: Char = ' '
    var ifNumeric: Boolean = true
    var secondResultLenght = 0
    var totalTransaction = 0
    var resultTextValue=MutableLiveData<Double>()
    var calculationTextValue=MutableLiveData<String>()
    var totalCalculation= mutableListOf<String>()
    lateinit var passCalcuation:Array<String>

    init {
        Timber.i("Calculator View Model created")
        resultTextValue.value=0.0
        calculationTextValue.value=""
        secondResult.value=0.0
    }


    fun calculator(operator: Char): Double {
        return when (operator) {
            '+' -> firstResult.plus(secondResult.value ?: 0.0)
            '-' -> firstResult.minus(secondResult.value ?: 0.0)
            '*' -> firstResult.times(secondResult.value ?: 1.0)
            '/' -> firstResult.div(secondResult.value ?: 1.0)
            else -> firstResult.rem(secondResult.value ?: 1.0)
        }
    }

    fun createCalculation() {
        //This we can use in future to create a list of calculation
        totalCalculation.add(totalTransaction,"$firstResult$operator${secondResult.value}=${resultTextValue.value}")
        firstResult = resultTextValue.value ?: 0.0
        totalTransaction++
        secondResult.value = 0.0
        secondResultLenght = 0
    }
    fun beforeEqualCalculation(){
        ifNumeric = false
        operatorEnabled = false
        resultTextValue.value = calculator(operator)
    }

    fun seprateNumber(number: Double) {
        if (operatorEnabled) {
            if (ifNumeric) {
                secondResult.value = number + (secondResult.value?.times(10.0))!!
            } else {
                secondResult.value = number
            }
        } else {
            firstResult = number + (firstResult * 10)
        }
    }
    fun clearText() {
        resultTextValue.value= 0.0
        calculationTextValue.value = ""
        firstResult = 0.0
        secondResult.value = 0.0
        secondResultLenght = 0
        operator = ' '
        operatorEnabled = false
        ifNumeric = false
    }
    override fun onCleared() {
        super.onCleared()
        Timber.i("Calculator ViewModel destroyed")
    }
}


