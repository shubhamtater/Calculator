package com.kotlin_developer.margincalculator.calculator

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.kotlin_developer.margincalculator.R
import com.kotlin_developer.margincalculator.databinding.FragmentTotalCalculationBinding

class TotalCalculation : Fragment() {
    lateinit var binding: FragmentTotalCalculationBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_total_calculation, container, false
        )
        var args =
            TotalCalculationArgs.fromBundle(
                arguments!!
            )
        var totalTransaction = args.totalTransaction
        var totalCalculation = args.calculationResult

        binding.totalSolutions.setText(totalTransaction.toString())

        binding.calculationView.text = "${binding.calculationView.text}$totalCalculation \n\n"

        return binding.root
    }
}
