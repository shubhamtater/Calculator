package com.kotlin_developer.margincalculator.calculator

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.kotlin_developer.margincalculator.R
import com.kotlin_developer.margincalculator.databinding.FragmentCalculatorScreenBinding
import kotlinx.android.synthetic.main.calculator_button.view.*
import timber.log.Timber

class CalculatorScreen : Fragment(), LifecycleObserver {

    lateinit var action: CalculatorScreenDirections.ActionCalculatorScreenToTotalCalculation
    lateinit var viewModel: CalculatorViewModel

    init {
        this.lifecycle.addObserver(this)
    }

    lateinit var binding: FragmentCalculatorScreenBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding =
            DataBindingUtil.inflate(
                inflater,
                R.layout.fragment_calculator_screen, container, false
            )
        viewModel = ViewModelProvider(this).get(CalculatorViewModel::class.java)

        binding.include.oneBtn.setOnClickListener {
            ifSeprateNumber(1.0)
        }
        binding.include.twoBtn.setOnClickListener {
            ifSeprateNumber(2.0)
        }
        binding.include.threeBtn.setOnClickListener {
            ifSeprateNumber(3.0)
        }
        binding.include.fourBtn.setOnClickListener {
            ifSeprateNumber(4.0)
        }
        binding.include.fiveBtn.setOnClickListener {
            ifSeprateNumber(5.0)
        }
        binding.include.sixBtn.setOnClickListener {
            ifSeprateNumber(6.0)
        }
        binding.include.sevenBtn.setOnClickListener {
            ifSeprateNumber(7.0)
        }
        binding.include.eightBtn.setOnClickListener {
            ifSeprateNumber(8.0)
        }
        binding.include.nineBtn.setOnClickListener {
            ifSeprateNumber(9.0)
        }
        binding.include.zeroBtn.setOnClickListener {
            ifSeprateNumber(0.0)
        }
        binding.include.doubleZeroBtn.setOnClickListener {
            viewModel.secondResult.value?.times(10.0)
            ifSeprateNumber(0.0)
        }
        binding.include.clearBtn.setOnClickListener {
            viewModel.ifNumeric = false
            viewModel.clearText()
        }
        binding.include.plusBtn.setOnClickListener {
            viewModel.operator = '+'
            addTextToField()
        }
        binding.include.minuBtn.setOnClickListener {
            viewModel.operator = '-'
            addTextToField()
        }
        binding.include.divideBtn.setOnClickListener {
            viewModel.operator = '/'
            addTextToField()
        }
        binding.include.multipleBtn.setOnClickListener {
            viewModel.operator = '*'
            addTextToField()
        }
        binding.include.reminderBtn.setOnClickListener {
            viewModel.operator = '%'
            addTextToField()
        }
        binding.include.equalBtn.setOnClickListener {
            equalButton()
        }
        binding.include.backBtn.setOnClickListener {
//            binding.calculationText.text = binding.calculationText.text.dropLast(1).toDouble().toString()
            TODO("Implement Back Button")
        }

        binding.totalTransaction.setOnClickListener {

            action =
                CalculatorScreenDirections.actionCalculatorScreenToTotalCalculation(
                    viewModel.totalTransaction,
                    viewModel.totalCalculation[viewModel.totalTransaction - 1]
                )
            findNavController().navigate(action)
            Timber.i("Total transaction ${viewModel.totalTransaction} and final calculation ${viewModel.totalCalculation} ")
        }
        viewModel.resultTextValue.observe(viewLifecycleOwner, Observer { setResult ->
            binding.resultText.text = setResult.toString()
        })

        viewModel.calculationTextValue.observe(viewLifecycleOwner, Observer { setCalculation ->
            binding.calculationText.text = setCalculation
        })

        viewModel.secondResult.observe(viewLifecycleOwner, Observer {

        })

        return binding.root
    }

    private fun equalButton() {
        viewModel.beforeEqualCalculation()
        viewModel.calculationTextValue.value = binding.calculationText.text.toString()
        binding.resultText.text = viewModel.resultTextValue.value.toString()
        viewModel.createCalculation()
    }


    fun ifSeprateNumber(number: Double) {
        viewModel.seprateNumber(number)
        if (viewModel.operatorEnabled) {
            secondCalculationText()
        } else {
            binding.calculationText.text = viewModel.firstResult.toString()
        }
        viewModel.ifNumeric = true
    }

    fun secondCalculationText() {
        binding.calculationText
            .setText(
                binding.calculationText.text
                    .removeRange(
                        binding.calculationText.length() - viewModel.secondResultLenght,
                        binding.calculationText.length()
                    )
            )
        binding.calculationText.text =
            "${binding.calculationText.text}${viewModel.secondResult.value.toString()}"
        viewModel.secondResultLenght = viewModel.secondResult.value.toString().length
        viewModel.ifNumeric = true
    }

    fun addTextToField() {
        viewModel.ifNumeric = false
        viewModel.operatorEnabled = true
        binding.calculationText.setText("${binding.calculationText.text}${viewModel.operator}")
    }
}
